# Changelog

All notable changes to the US Stock Screener are recorded here.
Format loosely follows Keep a Changelog. Dates are when the build was cut.

## [1.2.1] - 2026-05-22

### Fixed
- **Sector and Industry dropdowns were stuck on "(All)" only** - the
  populate function was calling `BeginUpdate()` / `EndUpdate()` on the
  ComboBox controls, which silently failed because those methods only
  exist on ListBox (not ComboBox). The exception aborted the function
  before any sector/industry items got added. Removed those calls.

## [1.2.0] - 2026-05-22

### Fixed
- **Live price refresh now actually refreshes every ticker.** v1.1.0
  fetched all tickers but silently dropped any that yfinance's `fast_info`
  call returned None for - which on a 715-ticker grid was usually most
  of them. Result: a refresh would update 39 of 715 rows and overwrite
  the CSV, wiping out previously-good prices on the other 676 (which
  then showed "-"). The fix has three parts:
  - **`.info` fallback with 2 retries:** when `fast_info` returns None
    we now fall back to the slower `get_info()` then `.info` path,
    same as the screener does. Two retries with backoff handle transient
    Yahoo rate-limiting.
  - **Batches of 50 with a 1.0s pause between them.** Instead of
    slamming Yahoo with 715 concurrent requests, we go in 15 polite
    waves. Total time: 60-90 seconds for ~715 tickers.
  - **Merge instead of overwrite.** The Python now reads the existing
    `live_prices.csv` first and updates only tickers it successfully
    fetched. Failed tickers keep their last-known price instead of
    going to "-".
- **Progressive UI updates during refresh.** Since refresh now takes
  60-90s, the Python writes the CSV after every batch (every ~3-5s)
  and the UI's existing 1-second poll detects the change and reloads
  the grid. You see prices fill in as batches complete, instead of
  staring at "-" for 90 seconds.
- **`$Vol M` column header.** The dollar sign in the column header was
  being interpreted by PowerShell as a variable prefix and was getting
  swallowed. Escaped so it renders as a literal `$` now.

### Changed
- **Sector and Industry are now dependent single-select dropdowns** in
  place of the v1.1.0 multi-select listboxes. Pick a Sector and the
  Industry dropdown is filtered to only industries that actually exist
  within that Sector in your data. Each dropdown has `(All)` as the
  first option to clear the filter.
- **Sector and Industry columns removed from the grid.** Since those
  values are now used exclusively for filtering via the dropdowns,
  showing them as columns was redundant grid clutter. The data is still
  in screen_data.csv and is still used for the dropdowns - it just
  isn't rendered as a column anymore.
- **Removed "Clear Sector/Industry" button.** Redundant now that each
  dropdown has its own `(All)` option.
- "More" expander is now 140px tall (was 180px) since the listboxes
  were taller than dropdowns.

## [1.1.0] - 2026-05-20

### Fixed
- **Live price refresh no longer reshuffles rows on scroll.** Previously,
  scrolling triggered a partial refresh of just the visible window, which
  meant rows "popped in" with live prices as they scrolled into view,
  making the grid feel like it was moving around. Now "Refresh Prices"
  fetches the entire filtered grid in one shot. Prices remain static
  between refreshes - they only update when the user clicks Refresh or
  the 60-second auto-refresh timer fires.

### Added
- **Sector and Industry multi-select listboxes** behind the More expander.
  Replaces the old "Sector contains" text filter. Lists are populated
  dynamically from the data actually in screen_data.csv (Ctrl-click for
  multi-select). A "Clear Sector/Industry" button resets them in one
  click. Industry filter is brand new.
- **"3mo Px" column** showing the actual price from 3 months ago,
  alongside the existing "3mo %". This makes the 3-month math
  transparent and verifiable at a glance (the math itself was audited
  and looks correct - the new column lets the user confirm on any row).

### Notes
- v1.1.0 requires a fresh full screen run to populate the new Px3moAgo
  column. The screener now writes 16 fields per row (was 15). Existing
  CSVs from v1.0.x will show the new column as blank until re-screened.
- The Sector/Industry pull from Yahoo is unchanged - it's the same
  hardcoded `info.get("sector")` / `info.get("industry")` path, with
  the same get_info()-then-fallback-to-.info resilience added in v1.0.0.

## [1.0.1] - 2026-05-19

### Fixed
- Setup.bat now installs `openpyxl` (required by the Excel export).
  v1.0.0's installer omitted it, so "Export to Excel" failed with
  "Make sure openpyxl is installed" on machines where it wasn't
  already present. The screener itself was unaffected (it doesn't
  use openpyxl), which is why the gap went unnoticed until export.
- README dependency list updated to include openpyxl.

### Note
If upgrading from 1.0.0 without re-running Setup.bat, install the
missing library once:  `pip install openpyxl`

## [1.0.0] - 2026-05-18

First version-controlled release. Feature-complete against the original
9-criteria handwritten spec.

### Screener (screener_full.py)
- HARD filters: price $10-60, market cap > $500M, price below 52-week high,
  avg daily volume > 500K shares, avg daily dollar volume > $5M
- TAGGED (filterable in UI, not hard filters): sector, industry,
  index membership (S&P 500 / Nasdaq-100 / Dow 30), AI (curated list),
  Uranium, 3-month % change, 3-month trend (price up AND positive slope)
- Resilient sector/industry fetch: tries get_info() then falls back to
  the .info property so it works across yfinance versions
- Atomic CSV writes; progress reported to data/screen_status.txt

### UI (StockUI.ps1)
- Three tabs: Screen, Cohorts, Test Trades
- Screen: live price overlay, green/red move tinting, pin-to-top
  (persists to pinned.csv, overrides filters), right-click context menu
  (send to trades, pin, refresh, copy, open in Yahoo)
- Collapsible "More" filter section (Sector / Trending-up / AI-only)
- Cohorts: per-price-band top-15 horizontal bar charts (owner-drawn,
  no charting dependency)
- Test Trades: editable paper-trading log, auto-fill on ticker entry,
  live P/L, algorithm scorecard, right-click menu
- Export to Excel: choice of current view or full dataset, two-sheet
  formatted workbook (Screen + Trades)
- Startup error trapping with message box + error_log.txt

### Backend / packaging
- price_refresh.py: fast per-ticker live price fetch
- export_excel.py: formatted .xlsx builder
- trades_init.py: trades.csv bootstrap
- Setup.bat: first-run installer (Python check, pip install, Desktop shortcut)
- Launch.bat: execution-policy-safe launcher
- CSV-only backend, no database

### Known limitations
- Live prices delayed ~15 min (free Yahoo data)
- Index tags depend on Wikipedia table structure being reachable/stable
- UI not runtime-tested by the author's tooling; verified via user screenshots
- Full screen takes ~45-60 min (per-ticker history + info fetch)

---

## Pre-1.0 history (not individually versioned)

Built iteratively before version control was introduced:
- Initial Python screener -> Excel dashboard with live Stocks data type
- Pivoted away from M365 Stocks data type (unreliable) to a
  Python-fetches-everything / Excel-displays model
- Rebuilt as a PowerShell + WinForms desktop UI (CSV backend)
- Fixed encoding bug (em-dashes broke Windows PowerShell ANSI parsing)
- Added Cohorts charts, Test Trades, context menus, pinning
- Expanded screener from 3 metrics to the full 9-criteria spec
- UI cleanup pass + Excel export
